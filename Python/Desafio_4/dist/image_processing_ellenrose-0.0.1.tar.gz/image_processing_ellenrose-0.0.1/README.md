# package_name

Description. 
The package image_processing_EllenRose is used to:
	Processing:
	- Histogram matching 
	- Structural similarity
	- Risize image 
	Utils:
	- Read image
	- Save image
	- Plot image 
	- Plot result 
	- Plot histogram 

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install image_processing_EllenRose

```bash
pip install image_processing_EllenRose
```


## Author
Ellen 

## License
[MIT](https://choosealicense.com/licenses/mit/)